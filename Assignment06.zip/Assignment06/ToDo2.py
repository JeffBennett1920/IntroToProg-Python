#-----------------------------------------------------------------------#

# Title:        ToDo2.py

# Dev:          Jeff Bennett

# Date:         February 18, 2018

# Desc:         Opens and manages an existing text file called ToDo.txt.
#               Uses Functions and Classes to accomplish the tasks.


# ChangeLog:    None yet
#-----------------------------------------------------------------------#

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all 'to do' items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item from the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-----------------------------------------------------------------------#

# Declare Values

strFileName = "./ToDo.txt"
strData = ""
dicRow = {}
lstTable = []


# Define Input/Output Functions and Class

#   Input choice from menu
#   Input task to add
#   Input task to delete

#   Output menu of choices
#   Output current list of tasks

class InOutput:
    @staticmethod
    def input_choice():
    # prompts for menu choice
        strChoice = str(input("Please select an option by entering its number: "))
        return strChoice

    @staticmethod
    def input_task_to_add():
    # prompts for task to add and its priority
        strNewTask = input("\nEnter the new task: ")
        strPriority = input("Enter the new task priority [High/Low]: ")
        return strNewTask, strPriority

    @staticmethod
    def input_task_to_delete():
    # prompts for task to delete
        strDelTask = input("Enter the task to be deleted: ")
        return strDelTask

    @staticmethod
    def print_menu():
    # shows menu of choices
        print("""Menu of Options:
        (1) Show current data 
        (2) Add a new item
        (3) Delete an existing item
        (4) Save  data to file and exit
        (5) Exit without saving data
        """)

    @staticmethod
    def print_current_tasks(DataTable):
    # takes a list of single entry (pair-value) dictionaries as parameter and outputs a table of tasks
        print("\nYour current list of tasks and priorities is:")
        for item in DataTable:
            print(item)

# Define Processing Functions and Class

#   Read text from file
#   Add task
#   Delete task
#   Write current tasks to file

class TextHandler:
    @staticmethod
    def read_text_file(FileName, DataTable):
    # reads a text file (of two comma separated strings) in 'r' mode and creates a file object
        objFile = open(FileName, "r")
        for line in objFile:
            strData = line.split(",")
            dicRow = {strData[0].strip(): strData[1].strip()}
            DataTable.append(dicRow)
        objFile.close()

    @staticmethod
    def add_task(Task, Priority, TableData):
    # combines new task and its priority in a dictionary and appends to list
        dicRow = {Task: Priority}
        TableData.append(dicRow)

    @staticmethod
    def delete_task(DelTask, TableData):
    # searches list for task to delete as the key in a dictionary and deletes that dictionary
        for dicRow in TableData:
            if DelTask in dicRow:
                TableData.remove(dicRow)

    @staticmethod
    def write_tasks_to_file(FileName, DataTable):
    # opens file in 'w' mode, writes tasks to file, closes file
        objFile = open(FileName, "w")
        for dicRow in DataTable:
            for myKey, myValue in dicRow.items():
                objFile.write(myKey + ", " + myValue + "\n")
        objFile.close()


# Main Program

TextHandler.read_text_file(strFileName,lstTable)
InOutput.print_current_tasks(lstTable)
while True:
    InOutput.print_menu()
    strChoice = InOutput.input_choice()

    if (strChoice == '1'):
        InOutput.print_current_tasks(lstTable)
        continue

    if (strChoice == '2'):
        strNewTask, strPriority = InOutput.input_task_to_add()
        TextHandler.add_task(strNewTask, strPriority, lstTable)
        InOutput.print_current_tasks(lstTable)
        continue

    if (strChoice == '3'):
        strDelTask = InOutput.input_task_to_delete()
        TextHandler.delete_task(strDelTask, lstTable)
        InOutput.print_current_tasks(lstTable)
        continue

    if (strChoice == '4'):
        TextHandler.write_tasks_to_file(strFileName,lstTable)
        print("Your changes have been saved to file.")
        lstTable.clear()
        TextHandler.read_text_file(strFileName, lstTable)
        InOutput.print_current_tasks(lstTable)
        break

    if (strChoice == '5'):
        lstTable.clear()
        print("Any changes have not been saved to file.")
        TextHandler.read_text_file(strFileName, lstTable)
        InOutput.print_current_tasks(lstTable)
        break

print("Good bye!")
