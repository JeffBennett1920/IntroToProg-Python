#-----------------------------------------------------------------------#

# Title:        ToDo.py

# Dev:          Jeff Bennett

# Date:         February 10, 2018

# Desc:         Opens and manages an existing text file called ToDo.txt

# ChangeLog:    None yet
#-----------------------------------------------------------------------#

"""
1.  Prior to running script, create the two line data file with the data Clean house, Low
    and Pay bills, High.

2.	When the program starts, load each row of data from the text file
    into a Python dictionary. (The data will be stored like a row in a table.)

3.  Add the new dictionary “row” into a Python list object (now the data will be managed as a table).

4.  Display the contents of the list to the user.

5.  Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

6.	Save the data from the table into the file when the program exits

"""
# Declare values and any constants.

strData = ""
dicRow = {}
lstTable = []

# Functions

def print_current_tasks(dics):   #takes a list of single entry (pair-value) dictionaries as parameter
    print("\nYour current list of tasks and priorities is:")
    for item in lstTable:
        print(item)

def menu():
    print("""Menu of Options:
    (1) Show current data 
    (2) Add a new item
    (3) Delete an existing item
    (4) Save  data to file and exit
    (5) Exit without saving data
    """)

# Manage the File: Input and Output

# Open text file, read each line, split on the comma, strip \n and white space, form dictionary row and append to list

objFile = open("ToDo.txt", "r")
for line in objFile:
    strData = line.split(",")
    dicRow = {strData[0].strip(): strData[1].strip()}
    lstTable.append(dicRow)
print_current_tasks(lstTable)

objFile.close()

while True:
    # Menu and Choice
    menu()
    choice = input("Please select an option by entering its number: ")

    if  choice == '1':
        print_current_tasks(lstTable)
        continue

    elif(choice == '2'):
        strNewTask = input("\nEnter the new task: ")
        strPriority = input("Enter the new task priority [High/Low]: ")
        dicRow = {strNewTask: strPriority}
        lstTable.append(dicRow)
        print_current_tasks(lstTable)
        continue

    elif(choice == '3'):
        strDelTask = input("\nEnter the task to be deleted: ")
        for dicRow in lstTable:
            if strDelTask in dicRow:
                lstTable.remove(dicRow)
        print_current_tasks(lstTable)
        continue

    elif(choice == '4'):
        objFile = open("ToDo.txt", "w")
        for dicRow in lstTable:
            for myKey, myValue in dicRow.items():
                objFile.write(myKey + ", " + myValue + "\n")
        objFile.close()
        print_current_tasks(lstTable)
        print("Your data has been saved to the file ToDo.txt and the file closed.")
        break


    elif(choice == '5'):
        print("New data not saved; original data saved and file closed. ")
        break

print("Good bye!")


